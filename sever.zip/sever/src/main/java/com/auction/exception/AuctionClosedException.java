package main.java.com.auction.exception;

public class AuctionClosedException {
    
}
