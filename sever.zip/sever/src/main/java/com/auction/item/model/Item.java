package main.java.com.auction.item.model;

public class Item extends Entity {

    
}
